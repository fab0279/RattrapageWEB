var xhr1 = new XMLHttpRequest();
var url2 = 'ajax/get_genre.php'; 
xhr1.open("GET", url2, true);
xhr1.onload = function() {
  try {
      var response = JSON.parse(xhr1.responseText);
      // Get the <select> elemen
      var select = document.getElementById("genre");
      // Loop through the response data and create options
      response.forEach(element => {
        var option = document.createElement("option");
        option.text = element.nom_genre; 
        option.value = element.nom_genre; 
        select.appendChild(option);
        
      });
    } catch (error) {
      console.error("Invalid JSON response:", xhr1.responseText, error);
    }
}
xhr1.onerror = function() {
    document.getElementById("error").innerText = "Network error. Unable to connect to the server.";
};

// Send the request
xhr1.send();