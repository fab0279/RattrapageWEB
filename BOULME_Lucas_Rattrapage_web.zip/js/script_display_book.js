const apiKey = 'AIzaSyCDpwJzeDzPK5CxODPNlKKk5t8-wskn00A';
const url_api = `https://www.googleapis.com/books/v1/volumes?q=new+releases&orderBy=newest&maxResults=15&key=${apiKey}`;


var xhr = new XMLHttpRequest();
var url1 = 'ajax/check-user-status.php'; 
var array_genre_like;
xhr.open("GET", url1, true);
xhr.onload = function() { 
    // Check if the request was successful
    if (xhr.status === 200) {
        try {
            // Parse the JSON response
            var response = JSON.parse(xhr.responseText);
            // Get the error element from the current page
            var connexionElement = document.getElementById("connexion");
            // If the user is connected, replace the element with a link to the user info page (Syteme de recommendation)
            if (response['status'] === "connected") {
                console.log(response);
                connexionElement.innerHTML = '<a href="user_info.html">Utilisateur</a>';
                array_genre_like = response.genre;
                console.log(array_genre_like);
                let genre_like_API = '';
                array_genre_like.forEach(element => {
                  genre_like_API += `subject:${element}`;
              });
                fetch(`https://www.googleapis.com/books/v1/volumes?q=${genre_like_API}&maxResults=15&key=${apiKey}`)
             .then(response => response.json())
             .then(data => {  
                displayBooks(data.items);
              })
             .catch(error => {
                alert(`Error fetching books: ${error.message}`);
              });



            } else {
              // affichage des livres nouveaux et sortie dernierement
                connexionElement.innerHTML = '<a href="connexion.html">Connexion</a>';
                fetch(url_api)
                .then(response => response.json())
                .then(data => {  
                   displayBooks(data.items);
                 })
                .catch(error => {
                   alert(`Error fetching books: ${error.message}`);
                 });
            }
        } catch(e) {
            // Handle JSON parsing error
            console.error("Could not parse JSON response", e);
        }
    }
};

// Handle network errors
xhr.onerror = function() {
    document.getElementById("error").innerText = "Network error. Unable to connect to the server.";
};

// Send the request
xhr.send();


// Fetch popular books from Google Books API


if (array_genre_like){

 
}else{

}

function displayBooks(books) {
  const bookList = document.getElementById('book-list');
  bookList.innerHTML = '';
  books.forEach(book => {
    const listItem = document.createElement('li');
    const title = document.createElement('h2');
    const author = document.createElement('p');
    const cover = document.createElement('img');
    const readButton = document.createElement('button');

    title.textContent = book.volumeInfo.title;
    if (book.volumeInfo.authors && book.volumeInfo.authors.length > 0) {
      author.textContent = book.volumeInfo.authors.join(', ');
    } else {
      author.textContent = 'Unknown author';
    }
    if (book.volumeInfo.imageLinks && book.volumeInfo.imageLinks.thumbnail) {
      cover.src = book.volumeInfo.imageLinks.thumbnail;
    } else {
      cover.src = "default_book_cover.jpg"; // Add a default book cover image
    }
    readButton.textContent = 'Read Online';

    listItem.appendChild(cover);
    listItem.appendChild(title);
    listItem.appendChild(author);
    listItem.appendChild(readButton);
    bookList.appendChild(listItem);

    // Add click event listener to read button
    readButton.addEventListener("click", (function(book) {
      return function() {
        // Ensure there are industry identifiers and filter for ISBN types
        const industryIdentifiers = book.volumeInfo.industryIdentifiers;
        const isbn = industryIdentifiers?.find(identifier => identifier.type.includes('ISBN'))?.identifier;

        if (isbn) {
          window.location.href = `lecture.html?isbn=${isbn}`;
        } else {
          alert("Can't read the book Google error");
        }
      };
    })(book));
  });
}

// Search functionality
const searchButton = document.getElementById('search');
const authorInput = document.getElementById('author');
const titleInput = document.getElementById('title');
const genreSelect = document.getElementById('genre');

searchButton.addEventListener('click', searchBooks);

function searchBooks() {
  const authorQuery = authorInput.value.trim();
  const titleQuery = titleInput.value.trim();
  const genreQuery = genreSelect.value.trim();

  console.log(authorInput,titleInput,genreQuery);

  if (!authorQuery && !titleQuery && !genreQuery) {
    return;
  }

  let query = '';
  if (authorQuery) {
    query += `inauthor:${authorQuery} `;
  }
  if (titleQuery) {
    query += `intitle:${titleQuery} `;
  }
  if (genreQuery) {
    query += `subject:${genreQuery} `;
  }
  console.log(query);
  query = query.trim();

  if (query) {
    const searchUrl = `https://www.googleapis.com/books/v1/volumes?q=${query}&key=${apiKey}`;
    fetch(searchUrl)
     .then(response => response.json())
     .then(data => {
        if (data.items && data.items.length > 0) {
          const searchResults = data.items;
          displayBooks(searchResults);
        } else {
          alert('No books found for your search query');
        }
      })
     .catch(error => {
        alert(`Error searching books: ${error.message}`);
      });
  }
}