<?php 
require_once '../includes/cl_genre.php';
    $genre = new Genre();
    $genre = $genre->get_genre_name();
    echo json_encode($genre);


    

?>