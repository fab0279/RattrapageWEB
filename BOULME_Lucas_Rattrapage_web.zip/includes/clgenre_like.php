<?php 
    declare (strict_types = 1);
    require_once 'db.php';
    class GenreLike{
        private $PDO;
        private $genre_array;
        private $user_id;
        private $errors = [];

        function __construct(array $genre_array,string $id){
            $this->genre_array = $genre_array;
            $this->user_id = $id;
            $this->PDO = new DB();
           
        }
        function get_id_genre($genre){
            $PDO1 = new DB();
            $PDO1 = $PDO1->connect();
            $sql = "SELECT id_genre FROM genre WHERE nom_genre = :genre";
            $query = $PDO1->prepare($sql);
            $query->bindParam(':genre', $genre);
            $query->execute();
            $id_genre = $query->fetch(PDO::FETCH_ASSOC);
            $PDO1 = null;
            return $id_genre;
        }
        function get_genre_name(){
            $this->PDO = $this->PDO->connect();
            $sql = "SELECT nom_genre FROM genre";
            $query = $this->PDO->prepare($sql);
            $query->execute();
            $genre_name = $query->fetchAll(PDO::FETCH_ASSOC);
            return $genre_name;
        }

        function execute_like(){
            $this->PDO= $this->PDO->connect();
            $sql = "INSERT INTO genre_like (ID_GENRE, ID_USER, COMPTEUR) VALUES (:genre, :user_id, 1)";
            foreach($this->genre_array as $genre){
                $id = $this->get_id_genre($genre); 
                $query = $this->PDO->prepare($sql);
                $query->bindParam(':genre', $id['id_genre']);
                $query->bindParam(':user_id', $this->user_id);
                $query->execute();
                if(!$query){
                    $this->errors["error"] = "Error";
                    $_SESSION['error'] = $this->errors;
                    header('Location: ../genre.html');
                    die();
                }
            }

            header('Location: ../index.html');
            die();
        }
    }
    









?>