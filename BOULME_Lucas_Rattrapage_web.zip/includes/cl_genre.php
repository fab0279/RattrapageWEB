<?php 
require_once 'db.php';
class Genre extends DB{
    private $PDO;

    function __construct(){
        $this->PDO = new DB();
    }
    function get_genre_name(){
        $this->PDO = $this->PDO->connect();
        $sql = "SELECT nom_genre FROM genre";
        $query = $this->PDO->prepare($sql);
        $query->execute();
        $genre_name = $query->fetchAll(PDO::FETCH_ASSOC);
        return $genre_name;
        $this->PDO = null;
    }
    function get_genre_like($id){
        $this->PDO = $this->PDO->connect();
        $sql = "SELECT genre.NOM_GENRE
        FROM genre 
        JOIN genre_like ON genre.ID_GENRE = genre_like.ID_GENRE
        WHERE genre_like.ID_USER = :id;";
        $query = $this->PDO->prepare($sql);
        $query->bindParam(':id', $id);
        $query->execute();
        $genre_like = $query->fetchAll(PDO::FETCH_ASSOC);
        return $genre_like;
        $this->PDO = null;
    }


}

?>