<?php 
    require_once 'clgenre_like.php';
    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        session_start();
        $checckbox = $_POST['genre'];
        $genre = new GenreLike($checckbox,$_SESSION['id']);
        $genre->execute_like();
        unset($_SESSION);
        session_destroy();
        header('Location: ../index.html');
        die();
    }
    else{
        header('Location: ../genre.html');
        die();

    }

?>